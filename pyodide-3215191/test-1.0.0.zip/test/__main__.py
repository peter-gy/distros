from test.libregrtest import main
main()
